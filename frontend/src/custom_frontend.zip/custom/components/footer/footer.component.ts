import { Component, OnInit } from '@angular/core';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { AppConfig } from '@geonature_config/app.config';

@Component({
  selector: 'pnx-footer',
  templateUrl: 'footer.component.html'
})
export class FooterComponent implements OnInit {
  public config = AppConfig;
  constructor(public ngbModal: NgbModal) {}

  ngOnInit() {}

  openModal(modal) {
    this.ngbModal.open(modal);
  }
}
